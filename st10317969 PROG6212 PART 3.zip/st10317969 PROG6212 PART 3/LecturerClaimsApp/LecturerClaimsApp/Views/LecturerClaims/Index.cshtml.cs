using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LecturerClaimsApp.Views.LecturerClaims
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
